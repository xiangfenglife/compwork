# -*- coding: utf-8 -*-
"""
:copyright: NSN
:author: Damian Pukacz
:contact: damian.pukacz@nokia.com
"""
