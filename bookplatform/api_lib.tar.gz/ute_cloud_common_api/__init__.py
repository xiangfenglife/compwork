# -*- coding: utf-8 -*-
"""
:copyright: NSN
:author: Bartłomiej Idzikowski
:contact: bartlomiej.idzikowski@nokia.com
"""
