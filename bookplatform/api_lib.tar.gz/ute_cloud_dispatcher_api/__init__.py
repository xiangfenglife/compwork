# -*- coding: utf-8 -*-
"""
:copyright: NSN
:author: Bartlomiej Idzikowski
:contact: bartlomiej.idzikowski@nsn.com
"""
